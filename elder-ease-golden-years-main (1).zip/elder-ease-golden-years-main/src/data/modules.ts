export type ModuleStep = { title: string; text: string; icon: string };
export type LearningModule = {
  id: string; title: string; icon: string; summary: string; level: "Beginner" | "Intermediate" | "Confident";
  minutes: number; steps: ModuleStep[];
};

export const MODULES: LearningModule[] = [
  { id: "basics", title: "Smartphone Basics", icon: "Smartphone", level: "Beginner", minutes: 15,
    summary: "Turn on your phone, unlock it, and find your way around the home screen.",
    steps: [
      { title: "Turn the phone on", icon: "Power", text: "Press and hold the button on the side of the phone for 3 seconds until the screen lights up." },
      { title: "Unlock the screen", icon: "Unlock", text: "Swipe your finger upward from the bottom of the screen. Enter your PIN if asked." },
      { title: "Open an app", icon: "LayoutGrid", text: "Tap once on a small picture, called an icon, to open that app." },
      { title: "Go back home", icon: "Home", text: "Swipe up from the bottom or press the round home button to return to the home screen." },
    ] },
  { id: "calls", title: "Making Calls and Video Calls", icon: "Video", level: "Beginner", minutes: 12,
    summary: "Call family members and see their faces with a video call.",
    steps: [
      { title: "Open the Phone app", icon: "Phone", text: "Tap the green phone icon on your home screen." },
      { title: "Choose a contact", icon: "Users", text: "Tap Contacts and then tap the name of the person you want to call." },
      { title: "Start a video call", icon: "Video", text: "Tap the camera icon next to the name to start a video call." },
      { title: "End the call", icon: "PhoneOff", text: "Tap the red button to end the call when you are done." },
    ] },
  { id: "whatsapp", title: "WhatsApp and Messaging", icon: "MessageCircle", level: "Beginner", minutes: 15,
    summary: "Send messages, photos and voice notes to family and friends.",
    steps: [
      { title: "Open WhatsApp", icon: "MessageCircle", text: "Tap the green speech bubble icon." },
      { title: "Pick a chat", icon: "Users", text: "Tap the name of the person you want to message." },
      { title: "Type or speak", icon: "Mic", text: "Type in the box at the bottom, or hold the microphone to record a voice note." },
      { title: "Send", icon: "Send", text: "Tap the green arrow to send your message." },
    ] },
  { id: "upi", title: "UPI and Digital Payments", icon: "IndianRupee", level: "Intermediate", minutes: 20,
    summary: "Pay safely using UPI apps by scanning a QR code.",
    steps: [
      { title: "Open your UPI app", icon: "Wallet", text: "Open an app like BHIM, Google Pay or PhonePe." },
      { title: "Scan the QR code", icon: "QrCode", text: "Tap Scan and point your camera at the shop's QR code." },
      { title: "Enter the amount", icon: "IndianRupee", text: "Type the amount and check the shop's name carefully." },
      { title: "Enter your UPI PIN", icon: "Lock", text: "Type your secret PIN. Never share this PIN with anyone. You never need a PIN to receive money." },
    ] },
  { id: "gov", title: "Online Government Services", icon: "Landmark", level: "Intermediate", minutes: 18,
    summary: "Use DigiLocker, pension and Aadhaar services from home.",
    steps: [
      { title: "Use official websites", icon: "ShieldCheck", text: "Government websites end with .gov.in. Check the address before typing anything." },
      { title: "Open DigiLocker", icon: "FolderLock", text: "DigiLocker keeps your documents like Aadhaar and PAN safely on your phone." },
      { title: "Life certificate", icon: "FileCheck", text: "Pensioners can submit the Jeevan Pramaan life certificate online." },
    ] },
  { id: "booking", title: "Booking Tickets and Appointments", icon: "CalendarCheck", level: "Intermediate", minutes: 20,
    summary: "Book train tickets and doctor appointments online.",
    steps: [
      { title: "Choose the right app", icon: "Train", text: "Use IRCTC for trains, or your hospital's official app for doctors." },
      { title: "Pick date and time", icon: "CalendarDays", text: "Tap the calendar and choose a date that suits you." },
      { title: "Confirm and save", icon: "CheckCircle", text: "Check the details, pay, and take a screenshot of your booking." },
    ] },
  { id: "safety", title: "Online Safety", icon: "ShieldCheck", level: "Confident", minutes: 15,
    summary: "Spot scams, protect your OTP and keep your bank details safe.",
    steps: [
      { title: "Never share OTP", icon: "KeyRound", text: "Banks never ask for your OTP, PIN or password on a call." },
      { title: "Check links", icon: "Link", text: "Do not tap links in messages from unknown numbers." },
      { title: "Report fraud", icon: "Siren", text: "Call 1930 immediately if you are cheated online." },
    ] },
];

export const ASSESSMENT = [
  { q: "Can you unlock your phone on your own?", recommends: "basics" },
  { q: "Can you make a video call to your family?", recommends: "calls" },
  { q: "Do you send WhatsApp messages?", recommends: "whatsapp" },
  { q: "Have you paid money using UPI?", recommends: "upi" },
  { q: "Have you used a government website?", recommends: "gov" },
  { q: "Have you booked a ticket online?", recommends: "booking" },
  { q: "Do you know never to share your OTP?", recommends: "safety" },
];

export const BADGES = [
  { id: "first", name: "First Step", icon: "Footprints", needs: 1 },
  { id: "three", name: "Quick Learner", icon: "Zap", needs: 3 },
  { id: "five", name: "Digital Star", icon: "Star", needs: 5 },
  { id: "all", name: "Independent", icon: "Trophy", needs: 7 },
];
