export const QUICK_QUESTIONS = [
  "How do I make a video call?",
  "How do I send money?",
  "How do I make text bigger?",
  "Is this call a scam?",
];

const ANSWERS: { keys: string[]; answer: string }[] = [
  { keys: ["video", "call"], answer: "Open WhatsApp, tap the name of your family member, then tap the small camera icon at the top. Wait for them to answer. Tap the red button to end." },
  { keys: ["money", "pay", "upi", "send"], answer: "Open your UPI app, tap Scan, point the camera at the QR code, check the name, type the amount and enter your secret PIN. Never share your PIN." },
  { keys: ["text", "bigger", "font", "size"], answer: "Open Settings, tap Display, then Font size, and slide it to the right. You can also use the A plus button on this website." },
  { keys: ["scam", "fraud", "otp"], answer: "If anyone asks for your OTP, PIN or asks you to pay to receive a prize, it is a scam. Hang up and call 1930 if you lost money." },
];

export const mockAnswer = (q: string) => {
  const s = q.toLowerCase();
  return ANSWERS.find((a) => a.keys.some((k) => s.includes(k)))?.answer
    ?? "That is a good question. A volunteer can help you with this. Would you like to book a free session in the Community section?";
};
