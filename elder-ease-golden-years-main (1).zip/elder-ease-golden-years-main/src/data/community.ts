export const MENTORS = [
  { id: "m1", name: "Priya Sahoo", role: "Student volunteer, KIIT", type: "youth", languages: ["Odia", "English"], availability: "Weekends, 10am–1pm", photo: "https://randomuser.me/api/portraits/women/68.jpg" },
  { id: "m2", name: "Arjun Mehta", role: "Engineering student", type: "youth", languages: ["Hindi", "English"], availability: "Weekdays, 5–7pm", photo: "https://randomuser.me/api/portraits/men/32.jpg" },
  { id: "m3", name: "Kavya Reddy", role: "NSS volunteer", type: "youth", languages: ["Telugu", "Tamil"], availability: "Saturdays", photo: "https://randomuser.me/api/portraits/women/44.jpg" },
  { id: "m4", name: "Shanti Devi, 72", role: "Retired teacher — stories & poetry", type: "elder", languages: ["Hindi"], availability: "Mornings", photo: "https://randomuser.me/api/portraits/women/79.jpg" },
  { id: "m5", name: "Ramesh Panda, 68", role: "Pattachitra painting & crafts", type: "elder", languages: ["Odia"], availability: "Sundays", photo: "https://randomuser.me/api/portraits/men/75.jpg" },
  { id: "m6", name: "Lakshmi Iyer, 70", role: "Traditional recipes", type: "elder", languages: ["Tamil", "English"], availability: "Afternoons", photo: "https://randomuser.me/api/portraits/women/90.jpg" },
];

export const RESOURCES = [
  { id: "r1", title: "Make your phone text bigger in 3 taps", author: "Arjun M.", votes: 42 },
  { id: "r2", title: "Grandma's video: how I order medicines online", author: "Shanti D.", votes: 37 },
  { id: "r3", title: "Checklist before you pay with UPI", author: "Priya S.", votes: 29 },
  { id: "r4", title: "Recording voice notes for family abroad", author: "Lakshmi I.", votes: 18 },
];

export const TESTIMONIALS = [
  { quote: "I can now video call my granddaughter in Bengaluru by myself. I feel so proud.", name: "Sarojini Mishra, 69", role: "Senior learner, Cuttack" },
  { quote: "Teaching Dadaji UPI taught me patience — and he taught me how to make perfect chai.", name: "Rohan Das, 20", role: "Student volunteer" },
];

export const FAQ = [
  { q: "Is ElderEase free to use?", a: "Yes. Learning, practice and volunteer sessions are free for senior citizens." },
  { q: "Can I practise without losing real money?", a: "Yes. The Practice section uses pretend money only. Nothing you do there is real." },
  { q: "Which languages are available?", a: "English, Hindi and Odia today, with Bengali, Tamil and Telugu coming soon." },
  { q: "How do I get help from a person?", a: "Book a session with a volunteer in the Community section, or request a call back below." },
  { q: "What do I do if I was cheated online?", a: "Call the national cyber fraud helpline 1930 immediately, or report at cybercrime.gov.in." },
];
