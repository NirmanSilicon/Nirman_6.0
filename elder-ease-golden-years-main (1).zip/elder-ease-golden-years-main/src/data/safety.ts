export const THREATS = [
  { title: "Phishing", icon: "Fish", text: "Fake messages or emails pretending to be your bank, asking you to click a link or share details." },
  { title: "Fraudulent calls", icon: "PhoneIncoming", text: "Callers pretending to be bank staff, police or relatives in trouble, asking for money urgently." },
  { title: "Suspicious links", icon: "Link2Off", text: "Links promising prizes, KYC updates or refunds that lead to fake websites." },
  { title: "OTP & banking misuse", icon: "KeyRound", text: "Your OTP, PIN, CVV and password are secret. The RBI says banks will never ask for them." },
];

export const SCAM_QUIZ = [
  { kind: "SMS", text: "Dear customer, your SBI account will be blocked today. Update KYC now: http://sbi-kyc-update.in", scam: true, why: "Banks never send KYC links by SMS. The web address is fake." },
  { kind: "Call", text: "\"Hello, I'm from your bank. Please tell me the OTP you just received so I can stop a fraud.\"", scam: true, why: "No bank employee will ever ask for your OTP." },
  { kind: "SMS", text: "Your OTP for login is 482910. Do not share this with anyone. — HDFC Bank", scam: false, why: "This is a normal OTP message you requested. It even warns you not to share it." },
  { kind: "Email", text: "Congratulations! You won ₹25 lakh in the KBC lottery. Pay ₹5,000 processing fee to claim.", scam: true, why: "Real prizes never ask you to pay a fee. You did not enter any lottery." },
  { kind: "SMS", text: "Rs. 500 debited from your A/c XX1234 for electricity bill. — Your bank", scam: false, why: "A plain transaction alert with no link or request is usually genuine. Check your passbook if unsure." },
];

export const DOS = ["Keep your phone locked with a PIN", "Check website addresses end in .gov.in or your bank's real name", "Call your bank on the number printed on your card", "Ask a family member or volunteer when unsure"];
export const DONTS = ["Share OTP, PIN, CVV or passwords", "Click links from unknown numbers", "Install apps a caller asks you to install", "Scan a QR code to receive money"];
