import { createFileRoute } from "@tanstack/react-router";
import { pageHead } from "@/lib/head";
import { PageShell } from "@/components/site/PageShell";
import { VoiceAssistant } from "@/components/site/VoiceAssistant";

export const Route = createFileRoute("/voice")({
  head: () => pageHead("Voice Assistant", "Ask questions out loud in your language and hear simple answers about using your phone."),
  component: () => (
    <PageShell kicker="SPEAK & LISTEN" title="Voice Assistant" intro="Press the big microphone and ask your question. The answer will be read aloud. Choose your language at the top of the page.">
      <div className="mx-auto max-w-3xl"><VoiceAssistant /></div>
    </PageShell>
  ),
});
