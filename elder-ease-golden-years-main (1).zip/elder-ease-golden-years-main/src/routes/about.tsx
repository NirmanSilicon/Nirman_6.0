import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { pageHead } from "@/lib/head";
import { PageShell, SectionTitle } from "@/components/site/PageShell";
import { FeatureCard } from "@/components/site/FeatureCard";
import { ListenButton } from "@/components/site/ListenButton";

export const Route = createFileRoute("/about")({
  head: () => pageHead("About", "ElderEase is a Digital Empowerment and Intergenerational Learning Platform for Senior Citizens by team SheBuilds."),
  component: About,
});

const FEAS = {
  Technical: ["Readily available mobile and web technologies", "Cloud database and authentication", "Built-in smartphone voice accessibility", "Multilingual content", "Scalable architecture"],
  Economic: ["Low initial development cost", "Free open-source tools", "No specialised hardware for the prototype", "Student volunteers reduce training and outreach costs"],
  Operational: ["Simple interface with large icons and readable text", "Easy audio and visual instructions", "Volunteer-assisted learning sessions", "Community-based feedback and support"],
  "Future viability": ["Collaboration with colleges, NGOs and senior citizen associations", "Expansion across rural and urban communities", "More regional languages", "Digital literacy programmes", "Institutional partnerships"],
};
type Tab = keyof typeof FEAS;

function About() {
  const [tab, setTab] = useState<Tab>("Technical");
  return (
    <PageShell kicker="ABOUT US" title="About ElderEase" intro="Digital Empowerment and Intergenerational Learning Platform for Senior Citizens.">
      <div className="grid gap-6 md:grid-cols-3">
        <FeatureCard icon="Target" title="Our Mission" text="Help every senior citizen use smartphones and online services confidently, safely and independently." />
        <FeatureCard icon="Eye" title="Our Vision" text="A digitally inclusive India where no elder is left behind and generations learn from each other." />
        <FeatureCard icon="Users" title="Team SheBuilds" text="A team of women builders creating ElderEase for Nirman Hacknation under the Open Innovation theme." />
      </div>
      <div className="mt-16">
        <SectionTitle kicker="IS IT POSSIBLE?" title="Feasibility & Viability" />
        <div role="tablist" aria-label="Feasibility" className="mt-8 flex flex-wrap gap-2">
          {(Object.keys(FEAS) as Tab[]).map((k) => (
            <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`min-h-14 rounded-sm border-2 border-navy px-5 text-lg font-semibold ${tab === k ? "bg-primary text-primary-foreground" : "bg-card text-navy"}`}>{k}</button>
          ))}
        </div>
        <div role="tabpanel" className="mt-6 rounded-md border border-border bg-card p-8">
          <ul className="grid gap-3 text-xl sm:grid-cols-2">{FEAS[tab].map((f) => <li key={f} className="flex gap-3"><span className="mt-2 h-3 w-3 shrink-0 rounded-full bg-teal" />{f}</li>)}</ul>
          <ListenButton className="mt-6" text={`${tab} feasibility. ${FEAS[tab].join(". ")}`} />
        </div>
      </div>
    </PageShell>
  );
}
