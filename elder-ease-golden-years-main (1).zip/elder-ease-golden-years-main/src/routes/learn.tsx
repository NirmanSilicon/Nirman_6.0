import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2, ThumbsUp, ThumbsDown } from "lucide-react";
import { pageHead } from "@/lib/head";
import { useApp } from "@/lib/app-context";
import { ASSESSMENT, MODULES, type LearningModule } from "@/data/modules";
import { PageShell, SectionTitle } from "@/components/site/PageShell";
import { ModuleCard } from "@/components/site/ModuleCard";
import { ListenButton } from "@/components/site/ListenButton";
import { Icon } from "@/components/site/Icon";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/learn")({
  head: () => pageHead("Learn", "Step-by-step smartphone lessons for seniors: calls, WhatsApp, UPI, government services and online safety."),
  component: Learn,
});

export function levelFor(yes: number, total: number) {
  const r = yes / total;
  return r < 0.4 ? "Beginner" : r < 0.8 ? "Intermediate" : "Confident";
}

function Assessment({ onDone }: { onDone: (missing: string[]) => void }) {
  const { setLevel } = useApp();
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const q = ASSESSMENT[i];
  const answer = (yes: boolean) => {
    const next = [...answers, yes];
    if (i + 1 < ASSESSMENT.length) { setAnswers(next); setI(i + 1); return; }
    setLevel(levelFor(next.filter(Boolean).length, ASSESSMENT.length));
    onDone(ASSESSMENT.filter((_, k) => !next[k]).map((a) => a.recommends));
  };
  if (!q) return null;
  return (
    <div className="rounded-md border-2 border-teal bg-card p-8">
      <p className="text-lg font-semibold text-accent">Question {i + 1} of {ASSESSMENT.length}</p>
      <Progress value={(i / ASSESSMENT.length) * 100} className="mt-2 h-3" />
      <h3 className="mt-6 text-3xl font-bold text-navy">{q.q}</h3>
      <ListenButton text={q.q} className="mt-4" />
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <button onClick={() => answer(true)} className="flex min-h-20 items-center justify-center gap-3 rounded-sm bg-primary text-2xl font-bold text-primary-foreground"><ThumbsUp className="h-8 w-8" aria-hidden /> Yes, I can</button>
        <button onClick={() => answer(false)} className="flex min-h-20 items-center justify-center gap-3 rounded-sm border-2 border-primary bg-card text-2xl font-bold text-primary"><ThumbsDown className="h-8 w-8" aria-hidden /> Not yet</button>
      </div>
    </div>
  );
}

function Lesson({ m, onClose }: { m: LearningModule; onClose: () => void }) {
  const { t, completed, toggleComplete } = useApp();
  const [s, setS] = useState(0);
  const step = m.steps[s]!;
  const done = completed.includes(m.id);
  return (
    <div className="rounded-md border-2 border-teal bg-card p-6 sm:p-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-3xl font-bold text-navy">{m.title}</h3>
        <button onClick={onClose} className="min-h-14 rounded-sm border-2 border-navy px-5 font-semibold">All lessons</button>
      </div>
      <p className="mt-4 text-lg font-semibold text-accent">Step {s + 1} of {m.steps.length}</p>
      <Progress value={((s + 1) / m.steps.length) * 100} className="mt-2 h-3" />
      <div className="mt-8 grid items-center gap-8 md:grid-cols-[auto_1fr]">
        <div className="grid h-48 w-48 place-items-center rounded-full bg-secondary text-accent"><Icon name={step.icon} className="h-24 w-24" /></div>
        <div>
          <h4 className="text-3xl font-bold text-navy">{s + 1}. {step.title}</h4>
          <p className="mt-3 text-2xl">{step.text}</p>
          <ListenButton key={s} text={`${step.title}. ${step.text}`} className="mt-5" />
        </div>
      </div>
      <div className="mt-8 flex flex-wrap gap-3">
        <button disabled={s === 0} onClick={() => setS(s - 1)} className="min-h-14 rounded-sm border-2 border-primary px-6 text-lg font-semibold disabled:opacity-40">{t("prev")}</button>
        {s < m.steps.length - 1 ? (
          <button onClick={() => setS(s + 1)} className="min-h-14 rounded-sm bg-primary px-8 text-lg font-semibold text-primary-foreground">{t("next")}</button>
        ) : (
          <button onClick={() => toggleComplete(m.id)} className="flex min-h-14 items-center gap-2 rounded-sm bg-success px-8 text-lg font-semibold text-accent-foreground">
            <CheckCircle2 className="h-6 w-6" aria-hidden /> {done ? "Completed! (tap to undo)" : t("complete")}
          </button>
        )}
      </div>
    </div>
  );
}

function Learn() {
  const { completed, level } = useApp();
  const [quiz, setQuiz] = useState(false);
  const [recs, setRecs] = useState<string[]>([]);
  const [open, setOpen] = useState<LearningModule | null>(null);
  return (
    <PageShell kicker="STEP BY STEP" title="Learn" intro="Short, simple lessons with big pictures. Take the quick quiz to see where to start, or pick any lesson below.">
      {quiz ? (
        <Assessment onDone={(r) => { setRecs(r); setQuiz(false); }} />
      ) : (
        <div className="flex flex-col items-start gap-4 rounded-md bg-sky p-8 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-navy">{level ? `Your level: ${level}` : "Find your starting point"}</h2>
            <p className="text-lg text-navy">{level ? "We've marked the lessons recommended for you." : "Answer 7 easy yes/no questions."}</p>
          </div>
          <button onClick={() => setQuiz(true)} className="min-h-16 rounded-sm bg-primary px-8 text-lg font-bold text-primary-foreground">{level ? "Retake quiz" : "Take the skill quiz"}</button>
        </div>
      )}
      <div className="mt-12">
        {open ? <Lesson m={open} onClose={() => setOpen(null)} /> : (
          <>
            <SectionTitle kicker="YOUR LEARNING PATH" title="Lessons" />
            <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[...MODULES].sort((a, b) => Number(recs.includes(b.id)) - Number(recs.includes(a.id))).map((m) => (
                <ModuleCard key={m.id} m={m} done={completed.includes(m.id)} recommended={recs.includes(m.id)} onOpen={() => { setOpen(m); window.scrollTo({ top: 300, behavior: "smooth" }); }} />
              ))}
            </div>
          </>
        )}
      </div>
    </PageShell>
  );
}
