import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { pageHead } from "@/lib/head";
import { PageShell } from "@/components/site/PageShell";
import { PhoneSimulator, type Scenario } from "@/components/site/PhoneSimulator";
import { Icon } from "@/components/site/Icon";

export const Route = createFileRoute("/practice")({
  head: () => pageHead("Practice", "Practise on a safe pretend smartphone: send messages, pay bills, book appointments and spot fake calls."),
  component: Practice,
});

const SCENARIOS: { id: Scenario; label: string; icon: string }[] = [
  { id: "whatsapp", label: "Send a WhatsApp message", icon: "MessageCircle" },
  { id: "bill", label: "Pay a bill", icon: "Receipt" },
  { id: "doctor", label: "Book a doctor appointment", icon: "Stethoscope" },
  { id: "fakecall", label: "Spot a fake call", icon: "PhoneOff" },
];

function Practice() {
  const [sc, setSc] = useState<Scenario>("whatsapp");
  return (
    <PageShell kicker="SAFE SIMULATION" title="Practice" intro="Try real tasks on a pretend phone. Nothing is real here, so you can't make a mistake that matters. Try again, no risk!">
      <div role="radiogroup" aria-label="Choose what to practise" className="mb-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {SCENARIOS.map((s) => (
          <button key={s.id} role="radio" aria-checked={sc === s.id} onClick={() => setSc(s.id)} className={`flex min-h-20 items-center gap-3 rounded-md border-2 p-4 text-left text-lg font-semibold ${sc === s.id ? "border-teal bg-secondary text-navy" : "border-border bg-card"}`}>
            <Icon name={s.icon} className="h-8 w-8 shrink-0 text-accent" /> {s.label}
          </button>
        ))}
      </div>
      <PhoneSimulator key={sc} scenario={sc} />
    </PageShell>
  );
}
