import { createFileRoute, Link } from "@tanstack/react-router";
import { Quote } from "lucide-react";
import heroImg from "@/assets/hero-elder-learning.jpg";
import { useApp } from "@/lib/app-context";
import { pageHead } from "@/lib/head";
import { FeatureCard } from "@/components/site/FeatureCard";
import { StepCard } from "@/components/site/StepCard";
import { SectionTitle } from "@/components/site/PageShell";
import { ListenButton } from "@/components/site/ListenButton";
import { Counter } from "@/components/site/Counter";
import { TESTIMONIALS } from "@/data/community";

export const Route = createFileRoute("/")({
  head: () => pageHead("Digital learning for senior citizens", "ElderEase makes digital life easier for elders with step-by-step lessons, safe practice, a voice assistant and student volunteers."),
  component: Index,
});

const PROBLEMS = [
  { icon: "ListOrdered", title: "Step-by-step digital learning", text: "Simple lessons with big pictures, one step at a time, at your own pace." },
  { icon: "Mic", title: "Regional language voice assistant", text: "Ask questions out loud in your own language and hear the answer." },
  { icon: "ShieldCheck", title: "Safe practice & cyber-safety", text: "Practise on a pretend phone and learn to spot scams with no risk." },
  { icon: "TrendingUp", title: "Progress tracking", text: "See how far you've come and grow more independent every week." },
];
const UNIQUE = [
  { icon: "Repeat", title: "Two-way intergenerational exchange", text: "Youth teach technology; elders share life skills, stories and traditions." },
  { icon: "Bot", title: "AI-assisted voice learning", text: "A friendly voice helper answers questions any time of day." },
  { icon: "Smartphone", title: "Safe simulation & community resources", text: "A practice phone plus tips and videos shared by the community." },
];
const STEPS = [
  { icon: "ClipboardCheck", title: "Assess", text: "A short, friendly quiz" },
  { icon: "Search", title: "Identify", text: "Find skills to learn" },
  { icon: "Route", title: "Recommend", text: "Your own learning path" },
  { icon: "HandHeart", title: "Support", text: "Voice help & volunteers" },
  { icon: "LineChart", title: "Track", text: "Watch your progress grow" },
];

function Index() {
  const { t } = useApp();
  return (
    <div className="animate-page-in">
      <section className="relative min-h-[620px] overflow-hidden">
        <img src={heroImg} alt="A grandmother and a student volunteer smiling at a smartphone together" width={1920} height={1088} fetchPriority="high" className="absolute inset-0 h-full w-full object-cover object-left" />
        <div className="absolute inset-0 bg-linear-to-r from-transparent via-sky-soft/60 to-sky-soft/95" />
        <div className="relative ml-auto flex min-h-[620px] max-w-2xl flex-col justify-center px-6 py-16 text-right sm:px-12">
          <p className="text-sm font-semibold tracking-mega text-navy sm:text-base">{t("heroKicker")}</p>
          <h1 className="mt-3 font-display text-5xl font-extrabold tracking-[0.12em] text-primary sm:text-7xl lg:text-8xl">{t("heroTitle")}</h1>
          <p className="mt-4 text-lg font-semibold tracking-mega text-navy">{t("heroSub")}</p>
          <div className="mt-8 flex flex-wrap justify-end gap-3">
            <Link to="/learn" className="inline-flex min-h-16 items-center bg-primary px-8 text-lg font-bold tracking-wider text-primary-foreground hover:opacity-90">{t("startLearning")}</Link>
            <Link to="/voice" className="inline-flex min-h-16 items-center border-2 border-primary bg-card px-8 text-lg font-bold tracking-wider text-primary hover:bg-secondary">{t("talkVoice")}</Link>
          </div>
        </div>
      </section>

      <section aria-label="Project overview" className="grid grid-cols-1 divide-y divide-border border-b border-border bg-card sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        {[["Theme", "Open Innovation"], ["Category", "Software"], ["Team", "SheBuilds"]].map(([k, v]) => (
          <div key={k} className="px-6 py-6 text-center"><p className="text-sm font-semibold tracking-mega text-accent">{k?.toUpperCase()}</p><p className="font-display text-2xl font-bold text-navy">{v}</p></div>
        ))}
      </section>

      <section className="px-5 py-16 sm:px-10">
        <SectionTitle kicker="WHAT WE SOLVE" title="Addressing the Problem" />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{PROBLEMS.map((p, i) => <FeatureCard key={p.title} {...p} index={i + 1} />)}</div>
      </section>

      <section className="bg-sky-soft px-5 py-16 sm:px-10">
        <div className="mx-auto max-w-4xl text-center">
          <SectionTitle kicker="OUR APPROACH" title="Proposed Solution" center />
          <p className="mt-6 text-2xl leading-relaxed text-navy">A simple digital learning platform that helps seniors understand smartphone basics, access online services and learn safe internet practices through guided support.</p>
          <ListenButton className="mt-6" text="A simple digital learning platform that helps seniors understand smartphone basics, access online services and learn safe internet practices through guided support." />
        </div>
      </section>

      <section className="px-5 py-16 sm:px-10">
        <SectionTitle kicker="WHY ELDEREASE" title="What makes ElderEase unique" />
        <div className="mt-10 grid gap-6 md:grid-cols-3">{UNIQUE.map((u) => <FeatureCard key={u.title} {...u} />)}</div>
      </section>

      <section className="border-y border-border bg-card px-5 py-16 sm:px-10">
        <SectionTitle kicker="SIMPLE STEPS" title="How it works" center />
        <ol className="mt-10 grid gap-8 sm:grid-cols-3 lg:grid-cols-5">{STEPS.map((s, i) => <StepCard key={s.title} n={i + 1} {...s} />)}</ol>
      </section>

      <section aria-label="Impact numbers" className="grid grid-cols-2 gap-6 bg-primary px-5 py-12 text-center text-primary-foreground sm:px-10 lg:grid-cols-4">
        {[[2400, "+", "Seniors learning"], [380, "+", "Student volunteers"], [12000, "+", "Lessons completed"], [6, "", "Languages"]].map(([n, s, l]) => (
          <div key={String(l)}><p className="font-display text-4xl font-extrabold sm:text-5xl"><Counter to={Number(n)} suffix={String(s)} /></p><p className="mt-1 text-lg tracking-wider">{l}</p></div>
        ))}
      </section>

      <section className="px-5 py-16 sm:px-10">
        <SectionTitle kicker="VOICES" title="What people say" />
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {TESTIMONIALS.map((tm) => (
            <figure key={tm.name} className="rounded-md border border-border bg-card p-8">
              <Quote className="h-10 w-10 text-accent" aria-hidden />
              <blockquote className="mt-3 text-2xl text-navy">“{tm.quote}”</blockquote>
              <figcaption className="mt-4 text-lg"><b>{tm.name}</b> · <span className="text-muted-foreground">{tm.role}</span></figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="mx-5 mb-16 flex flex-col items-center gap-6 bg-sky px-6 py-14 text-center sm:mx-10">
        <h2 className="font-display text-3xl font-bold uppercase tracking-wider text-navy sm:text-4xl">Join ElderEase today</h2>
        <p className="max-w-2xl text-xl text-navy">Learn at your own pace, or give a few hours a week to help an elder become independent.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link to="/join" search={{ role: "Senior learner" }} className="inline-flex min-h-16 items-center bg-primary px-8 text-lg font-bold text-primary-foreground">Join as a learner</Link>
          <Link to="/join" search={{ role: "Student volunteer" }} className="inline-flex min-h-16 items-center border-2 border-primary bg-card px-8 text-lg font-bold text-primary">Become a volunteer</Link>
        </div>
      </section>
    </div>
  );
}
