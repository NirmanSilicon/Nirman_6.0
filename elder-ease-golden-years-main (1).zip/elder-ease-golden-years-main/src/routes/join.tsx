import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { pageHead } from "@/lib/head";
import { submitForm } from "@/services/api";
import { PageShell } from "@/components/site/PageShell";

const ROLES = ["Senior learner", "Student volunteer", "Mentor", "NGO or College partner"];

export const Route = createFileRoute("/join")({
  validateSearch: (s: Record<string, unknown>): { role?: string } => (typeof s["role"] === "string" ? { role: s["role"] } : {}),
  head: () => pageHead("Join", "Join ElderEase as a senior learner, student volunteer, mentor, or NGO and college partner."),
  component: Join,
});

function Join() {
  const search = Route.useSearch();
  const [role, setRole] = useState(search.role ?? ROLES[0]!);
  const input = "min-h-14 w-full rounded-sm border-2 border-input bg-card px-4 text-xl";
  return (
    <PageShell kicker="BE PART OF IT" title="Join ElderEase" intro="Students, colleges, NGOs and senior citizen associations are all welcome.">
      <form className="mx-auto flex max-w-2xl flex-col gap-4" onSubmit={async (e) => { e.preventDefault(); await submitForm("join", { role }); toast.success("Thank you for joining! We'll call you soon."); }}>
        <fieldset className="grid gap-2 sm:grid-cols-2">
          <legend className="mb-2 text-lg font-semibold">I want to join as</legend>
          {ROLES.map((r) => (
            <button type="button" key={r} aria-pressed={role === r} onClick={() => setRole(r)} className={`min-h-14 rounded-sm border-2 text-lg font-semibold ${role === r ? "border-teal bg-secondary" : "border-input bg-card"}`}>{r}</button>
          ))}
        </fieldset>
        <label className="text-lg font-semibold" htmlFor="j-name">Full name</label>
        <input id="j-name" required className={input} />
        <label className="text-lg font-semibold" htmlFor="j-phone">Mobile number</label>
        <input id="j-phone" required inputMode="numeric" className={input} />
        <button className="min-h-16 rounded-sm bg-primary text-lg font-bold text-primary-foreground">Join now</button>
      </form>
    </PageShell>
  );
}
