/**
 * Placeholder API layer. Every function returns mock data today.
 * Replace the bodies with real calls to the Node.js + Express + Firebase backend later.
 */
import { mockAnswer } from "@/data/voice";

const delay = (ms = 400) => new Promise((r) => setTimeout(r, ms));

export async function askAssistant(question: string, _lang: string): Promise<string> {
  // TODO: plug in AI agent API here, e.g. POST /api/assistant { question, lang }
  await delay(600);
  return mockAnswer(question);
}

export async function bookSession(_data: Record<string, string>) {
  await delay();
  return { ok: true as const, id: "SES-" + Date.now().toString().slice(-5) };
}

export async function submitForm(_kind: "contact" | "callback" | "join" | "feedback", _data: Record<string, string>) {
  await delay();
  return { ok: true as const };
}

export async function requestOtp(_phone: string) {
  await delay();
  return { ok: true as const };
}
