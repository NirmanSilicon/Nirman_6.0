export const pageHead = (title: string, description: string) => ({
  meta: [
    { title: `${title} | ElderEase` },
    { name: "description", content: description },
    { property: "og:title", content: `${title} | ElderEase` },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ],
});
