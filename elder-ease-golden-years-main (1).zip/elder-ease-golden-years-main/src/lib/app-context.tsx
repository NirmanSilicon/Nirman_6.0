import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { LANGUAGES, translate, type DictKey, type LangCode } from "./i18n";

type Ctx = {
  lang: LangCode; setLang: (l: LangCode) => void; t: (k: DictKey) => string; speechLang: string;
  scale: number; setScale: (n: number) => void; contrast: boolean; setContrast: (b: boolean) => void;
  authOpen: boolean; setAuthOpen: (b: boolean) => void;
  completed: string[]; toggleComplete: (id: string) => void;
  level: string | null; setLevel: (l: string) => void;
};

const AppCtx = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<LangCode>("en");
  const [scale, setScale] = useState(1);
  const [contrast, setContrast] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [completed, setCompleted] = useState<string[]>(["basics"]);
  const [level, setLevel] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.style.fontSize = `${112.5 * scale}%`;
  }, [scale]);
  useEffect(() => {
    document.documentElement.classList.toggle("hc", contrast);
  }, [contrast]);
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const speechLang = LANGUAGES.find((l) => l.code === lang)?.speech ?? "en-IN";
  const toggleComplete = (id: string) =>
    setCompleted((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]));

  return (
    <AppCtx.Provider
      value={{
        lang, setLang, t: (k) => translate(lang, k), speechLang, scale, setScale, contrast, setContrast,
        authOpen, setAuthOpen, completed, toggleComplete, level, setLevel,
      }}
    >
      {children}
    </AppCtx.Provider>
  );
}

export function useApp() {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp must be used inside AppProvider");
  return c;
}
