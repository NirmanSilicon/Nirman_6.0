export const LANGUAGES = [
  { code: "en", label: "English", speech: "en-IN" },
  { code: "hi", label: "हिन्दी (Hindi)", speech: "hi-IN" },
  { code: "or", label: "ଓଡ଼ିଆ (Odia)", speech: "or-IN" },
  { code: "bn", label: "বাংলা (Bengali)", speech: "bn-IN" },
  { code: "ta", label: "தமிழ் (Tamil)", speech: "ta-IN" },
  { code: "te", label: "తెలుగు (Telugu)", speech: "te-IN" },
] as const;

export type LangCode = (typeof LANGUAGES)[number]["code"];

const en = {
  home: "Home", about: "About", learn: "Learn", practice: "Practice", safety: "Cyber-Safety",
  voice: "Voice Assistant", community: "Community", progress: "Progress", impact: "Impact",
  join: "Join", contact: "Contact", login: "Login", back: "Back", listen: "Listen", stop: "Stop",
  startLearning: "Start Learning", talkVoice: "Talk to Voice Assistant", letsChat: "Let's Chat!",
  readPage: "Read this page", textSize: "Text size", contrast: "High contrast", helpline: "Helpline",
  heroKicker: "INDEPENDENCE IS THE FIRST STEP TOWARDS", heroTitle: "CONFIDENCE",
  heroSub: "DIGITAL LEARNING FOR SENIOR CITIZENS", tagline: "Making digital life easier for elders.",
  platform: "DIGITAL LEARNING PLATFORM", next: "Next step", prev: "Previous", complete: "Mark as complete",
};
export type DictKey = keyof typeof en;

const hi: Partial<Record<DictKey, string>> = {
  home: "होम", about: "परिचय", learn: "सीखें", practice: "अभ्यास", safety: "साइबर सुरक्षा",
  voice: "आवाज़ सहायक", community: "समुदाय", progress: "प्रगति", impact: "प्रभाव", join: "जुड़ें",
  contact: "संपर्क", login: "लॉगिन", back: "वापस", listen: "सुनें", stop: "रोकें",
  startLearning: "सीखना शुरू करें", talkVoice: "आवाज़ सहायक से बात करें", letsChat: "बात करें!",
  readPage: "यह पेज सुनें", textSize: "अक्षर का आकार", contrast: "हाई कॉन्ट्रास्ट", helpline: "हेल्पलाइन",
  heroKicker: "आत्मनिर्भरता पहला कदम है", heroTitle: "आत्मविश्वास",
  heroSub: "वरिष्ठ नागरिकों के लिए डिजिटल शिक्षा", tagline: "बुज़ुर्गों के लिए डिजिटल जीवन आसान बनाना।",
  platform: "डिजिटल शिक्षा मंच", next: "अगला कदम", prev: "पिछला", complete: "पूरा हुआ",
};

const or: Partial<Record<DictKey, string>> = {
  home: "ମୂଳପୃଷ୍ଠା", about: "ବିଷୟରେ", learn: "ଶିଖନ୍ତୁ", practice: "ଅଭ୍ୟାସ", safety: "ସାଇବର ସୁରକ୍ଷା",
  voice: "ସ୍ୱର ସହାୟକ", community: "ସମୁଦାୟ", progress: "ପ୍ରଗତି", impact: "ପ୍ରଭାବ", join: "ଯୋଗ ଦିଅନ୍ତୁ",
  contact: "ଯୋଗାଯୋଗ", login: "ଲଗଇନ୍", back: "ପଛକୁ", listen: "ଶୁଣନ୍ତୁ", stop: "ବନ୍ଦ",
  startLearning: "ଶିଖିବା ଆରମ୍ଭ କରନ୍ତୁ", talkVoice: "ସ୍ୱର ସହାୟକ ସହ କଥା ହୁଅନ୍ତୁ", letsChat: "କଥା ହେବା!",
  readPage: "ଏହି ପୃଷ୍ଠା ଶୁଣନ୍ତୁ", textSize: "ଅକ୍ଷର ଆକାର", contrast: "ଉଚ୍ଚ କଣ୍ଟ୍ରାଷ୍ଟ", helpline: "ହେଲ୍ପଲାଇନ୍",
  heroKicker: "ଆତ୍ମନିର୍ଭରତା ପ୍ରଥମ ପଦକ୍ଷେପ", heroTitle: "ଆତ୍ମବିଶ୍ୱାସ",
  heroSub: "ବରିଷ୍ଠ ନାଗରିକଙ୍କ ପାଇଁ ଡିଜିଟାଲ ଶିକ୍ଷା", tagline: "ବୟସ୍କଙ୍କ ପାଇଁ ଡିଜିଟାଲ ଜୀବନ ସହଜ।",
  platform: "ଡିଜିଟାଲ ଶିକ୍ଷା ମଞ୍ଚ", next: "ପରବର୍ତ୍ତୀ", prev: "ପୂର୍ବବର୍ତ୍ତୀ", complete: "ସମ୍ପୂର୍ଣ୍ଣ",
};

// Bengali, Tamil and Telugu are placeholders and fall back to English for now.
const dicts: Record<LangCode, Partial<Record<DictKey, string>>> = { en, hi, or, bn: {}, ta: {}, te: {} };

export function translate(lang: LangCode, key: DictKey): string {
  return dicts[lang][key] ?? en[key];
}
