import { Link } from "@tanstack/react-router";
import { Phone, Menu, Facebook, Instagram, Youtube, Globe } from "lucide-react";
import { useState } from "react";
import { useApp } from "@/lib/app-context";
import { LANGUAGES, type DictKey, type LangCode } from "@/lib/i18n";
import { Logo } from "./Logo";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

export const NAV: { to: string; key: DictKey }[] = [
  { to: "/", key: "home" }, { to: "/about", key: "about" }, { to: "/learn", key: "learn" },
  { to: "/practice", key: "practice" }, { to: "/safety", key: "safety" }, { to: "/voice", key: "voice" },
  { to: "/community", key: "community" }, { to: "/progress", key: "progress" }, { to: "/contact", key: "contact" },
];

export function LanguageSelect({ id }: { id: string }) {
  const { lang, setLang } = useApp();
  return (
    <label htmlFor={id} className="flex items-center gap-2 text-base">
      <Globe className="h-5 w-5 text-accent" aria-hidden />
      <span className="sr-only">Language</span>
      <select id={id} value={lang} onChange={(e) => setLang(e.target.value as LangCode)} className="min-h-12 rounded-sm border-2 border-input bg-card px-2 text-base text-foreground">
        {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
      </select>
    </label>
  );
}

export function Navbar() {
  const { t, setAuthOpen } = useApp();
  const [open, setOpen] = useState(false);
  const linkCls = "rounded-sm px-2 py-2 text-[0.95rem] font-semibold text-navy hover:text-accent";
  const active = { className: "text-accent underline underline-offset-8 decoration-2" };
  return (
    <header className="border-b border-border bg-card">
      <div className="flex flex-wrap items-center justify-end gap-4 border-b border-border px-5 py-2 text-base sm:px-10">
        <a href="tel:18001801253" className="flex min-h-12 items-center gap-2 font-semibold text-navy"><Phone className="h-5 w-5 text-accent" aria-hidden /> {t("helpline")}: 1800-180-1253</a>
        <LanguageSelect id="lang-top" />
        <div className="hidden items-center gap-1 md:flex">
          {[{ I: Facebook, n: "Facebook" }, { I: Instagram, n: "Instagram" }, { I: Youtube, n: "YouTube" }].map(({ I, n }) => (
            <a key={n} href="#" aria-label={n} className="grid h-11 w-11 place-items-center rounded-full text-navy hover:text-accent"><I className="h-5 w-5" aria-hidden /></a>
          ))}
        </div>
        <button onClick={() => setAuthOpen(true)} className="min-h-12 rounded-sm bg-primary px-6 font-semibold text-primary-foreground hover:opacity-90">{t("login")}</button>
      </div>
      <nav aria-label="Main" className="flex items-center justify-between gap-4 px-5 py-4 sm:px-10">
        <Logo label={t("platform")} />
        <ul className="hidden flex-wrap items-center gap-x-2 xl:flex">
          {NAV.map((n) => (
            <li key={n.to}><Link to={n.to} className={linkCls} activeProps={active} activeOptions={{ exact: true }}>{t(n.key)}</Link></li>
          ))}
        </ul>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger className="flex min-h-14 items-center gap-2 rounded-sm border-2 border-navy px-4 font-semibold text-navy xl:hidden">
            <Menu className="h-6 w-6" aria-hidden /> Menu
          </SheetTrigger>
          <SheetContent side="right" className="w-80 bg-card">
            <SheetTitle className="font-display text-2xl text-navy">Menu</SheetTitle>
            <ul className="mt-6 flex flex-col gap-1">
              {[...NAV, { to: "/impact", key: "impact" as DictKey }, { to: "/join", key: "join" as DictKey }].map((n) => (
                <li key={n.to}><Link to={n.to} onClick={() => setOpen(false)} className="block min-h-14 rounded-sm px-3 py-3 text-xl font-semibold text-navy hover:bg-secondary" activeProps={active} activeOptions={{ exact: true }}>{t(n.key)}</Link></li>
              ))}
            </ul>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}
