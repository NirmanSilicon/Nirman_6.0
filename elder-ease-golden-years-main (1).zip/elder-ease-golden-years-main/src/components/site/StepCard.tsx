import { Icon } from "./Icon";

export function StepCard({ n, icon, title, text }: { n: number; icon: string; title: string; text: string }) {
  return (
    <li className="relative flex flex-col items-center text-center">
      <span className="grid h-20 w-20 place-items-center rounded-full border-4 border-teal bg-card text-accent">
        <Icon name={icon} className="h-9 w-9" />
      </span>
      <span className="mt-3 text-sm font-semibold tracking-mega text-accent">STEP {n}</span>
      <h3 className="mt-1 text-xl font-bold text-navy">{title}</h3>
      <p className="mt-1 text-base text-muted-foreground">{text}</p>
    </li>
  );
}
