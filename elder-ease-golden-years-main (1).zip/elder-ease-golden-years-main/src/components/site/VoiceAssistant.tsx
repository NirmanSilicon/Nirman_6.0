import { Mic, MicOff, Send } from "lucide-react";
import { useRef, useState } from "react";
import { useApp } from "@/lib/app-context";
import { createRecognition, speak } from "@/lib/speech";
import { askAssistant } from "@/services/api";
import { QUICK_QUESTIONS } from "@/data/voice";

type Msg = { from: "you" | "bot"; text: string };

export function VoiceAssistant({ compact }: { compact?: boolean }) {
  const { speechLang } = useApp();
  const [msgs, setMsgs] = useState<Msg[]>([{ from: "bot", text: "Namaste! I am your ElderEase helper. Press the big microphone and ask me anything about your phone." }]);
  const [listening, setListening] = useState(false);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const recRef = useRef<ReturnType<typeof createRecognition>>(null);

  const ask = async (q: string) => {
    if (!q.trim()) return;
    setMsgs((m) => [...m, { from: "you", text: q }]);
    setInput("");
    setBusy(true);
    const a = await askAssistant(q, speechLang); // AI agent API plugs in inside services/api.ts
    setBusy(false);
    setMsgs((m) => [...m, { from: "bot", text: a }]);
    speak(a, speechLang);
  };

  const toggleMic = () => {
    if (listening) { recRef.current?.stop(); return; }
    const r = createRecognition(speechLang);
    if (!r) { setMsgs((m) => [...m, { from: "bot", text: "Voice input isn't supported in this browser. Please type your question or tap a question below." }]); return; }
    recRef.current = r;
    r.onresult = (e) => { const t = e.results[0]?.[0]?.transcript; if (t) void ask(t); };
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    setListening(true);
    r.start();
  };

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col items-center gap-3">
        <button
          onClick={toggleMic}
          aria-pressed={listening}
          aria-label={listening ? "Stop listening" : "Start speaking"}
          className={`grid place-items-center rounded-full text-primary-foreground shadow-xl transition-transform ${compact ? "h-24 w-24" : "h-36 w-36"} ${listening ? "scale-105 animate-pulse bg-destructive" : "bg-primary hover:scale-105"}`}
        >
          {listening ? <MicOff className="h-1/2 w-1/2" aria-hidden /> : <Mic className="h-1/2 w-1/2" aria-hidden />}
        </button>
        <p className="text-lg font-semibold text-navy">{listening ? "Listening… speak now" : "Tap the microphone and speak"}</p>
      </div>
      <div className="flex flex-wrap justify-center gap-2">
        {QUICK_QUESTIONS.map((q) => (
          <button key={q} onClick={() => void ask(q)} className="min-h-12 rounded-full border-2 border-teal bg-card px-4 text-base font-semibold text-accent hover:bg-secondary">{q}</button>
        ))}
      </div>
      <div aria-live="polite" className={`flex flex-col gap-3 overflow-y-auto rounded-md border border-border bg-muted p-4 ${compact ? "max-h-72" : "max-h-[28rem]"}`}>
        {msgs.map((m, i) => (
          <p key={i} className={`max-w-[85%] rounded-md px-4 py-3 text-xl ${m.from === "you" ? "self-end bg-primary text-primary-foreground" : "self-start bg-card text-foreground"}`}>
            <span className="sr-only">{m.from === "you" ? "You said: " : "Assistant: "}</span>{m.text}
          </p>
        ))}
        {busy && <p className="self-start text-lg text-muted-foreground">Thinking…</p>}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); void ask(input); }} className="flex gap-2">
        <label htmlFor={compact ? "va-in-c" : "va-in"} className="sr-only">Type your question</label>
        <input id={compact ? "va-in-c" : "va-in"} value={input} onChange={(e) => setInput(e.target.value)} placeholder="Or type your question…" className="min-h-14 min-w-0 flex-1 rounded-sm border-2 border-input bg-card px-4 text-lg" />
        <button className="grid min-h-14 min-w-14 place-items-center rounded-sm bg-primary text-primary-foreground" aria-label="Send"><Send className="h-6 w-6" aria-hidden /></button>
      </form>
    </div>
  );
}
