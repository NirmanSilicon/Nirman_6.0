import { MessageCircle } from "lucide-react";
import { useApp } from "@/lib/app-context";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { VoiceAssistant } from "./VoiceAssistant";

export function ChatButton() {
  const { t } = useApp();
  return (
    <Sheet>
      <SheetTrigger className="fixed bottom-5 right-5 z-40 flex min-h-16 items-center gap-2 rounded-sm bg-primary px-6 font-display text-lg font-bold text-primary-foreground shadow-xl hover:opacity-90">
        <MessageCircle className="h-6 w-6" aria-hidden /> {t("letsChat")}
      </SheetTrigger>
      <SheetContent side="right" className="w-full overflow-y-auto bg-card sm:max-w-lg">
        <SheetTitle className="font-display text-2xl text-navy">{t("voice")}</SheetTitle>
        <div className="mt-4"><VoiceAssistant compact /></div>
      </SheetContent>
    </Sheet>
  );
}
