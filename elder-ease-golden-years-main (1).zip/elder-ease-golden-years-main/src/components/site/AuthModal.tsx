import { useState } from "react";
import { toast } from "sonner";
import { useApp } from "@/lib/app-context";
import { requestOtp } from "@/services/api";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";

const ROLES = ["Senior citizen", "Volunteer", "Mentor"];

export function AuthModal() {
  const { authOpen, setAuthOpen } = useApp();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [role, setRole] = useState(ROLES[0]!);
  const [phone, setPhone] = useState("");
  const [sent, setSent] = useState(false);
  const [otp, setOtp] = useState("");
  const input = "min-h-14 w-full rounded-sm border-2 border-input bg-card px-4 text-xl";

  return (
    <Dialog open={authOpen} onOpenChange={(o) => { setAuthOpen(o); if (!o) { setSent(false); setOtp(""); } }}>
      <DialogContent className="max-w-md bg-card">
        <DialogTitle className="font-display text-3xl text-navy">{mode === "login" ? "Welcome back" : "Create account"}</DialogTitle>
        <DialogDescription className="text-lg">Sign in with your mobile number. We will send you a one-time code.</DialogDescription>
        <div className="grid grid-cols-2 gap-2" role="tablist">
          {(["login", "signup"] as const).map((m) => (
            <button key={m} role="tab" aria-selected={mode === m} onClick={() => setMode(m)} className={`min-h-14 rounded-sm border-2 border-navy font-semibold ${mode === m ? "bg-primary text-primary-foreground" : "bg-card text-navy"}`}>
              {m === "login" ? "Login" : "Sign up"}
            </button>
          ))}
        </div>
        <fieldset>
          <legend className="mb-2 text-lg font-semibold">I am a</legend>
          <div className="grid grid-cols-3 gap-2">
            {ROLES.map((r) => (
              <button key={r} type="button" aria-pressed={role === r} onClick={() => setRole(r)} className={`min-h-14 rounded-sm border-2 px-1 text-base font-semibold ${role === r ? "border-teal bg-secondary text-navy" : "border-input text-muted-foreground"}`}>{r}</button>
            ))}
          </div>
        </fieldset>
        {!sent ? (
          <form className="flex flex-col gap-3" onSubmit={async (e) => { e.preventDefault(); if (phone.replace(/\D/g, "").length < 10) { toast.error("Please enter a 10-digit mobile number"); return; } await requestOtp(phone); setSent(true); toast.success("Code sent (demo: use 123456)"); }}>
            <label htmlFor="auth-phone" className="text-lg font-semibold">Mobile number</label>
            <input id="auth-phone" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="98765 43210" className={input} />
            <button className="min-h-14 rounded-sm bg-primary text-lg font-semibold text-primary-foreground">Send code</button>
          </form>
        ) : (
          <form className="flex flex-col gap-3" onSubmit={(e) => { e.preventDefault(); toast.success(`Welcome! Signed in as ${role} (demo)`); setAuthOpen(false); setSent(false); }}>
            <label htmlFor="auth-otp" className="text-lg font-semibold">Enter the 6-digit code</label>
            <input id="auth-otp" inputMode="numeric" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value)} className={`${input} text-center tracking-[0.5em]`} />
            <button disabled={otp.length !== 6} className="min-h-14 rounded-sm bg-primary text-lg font-semibold text-primary-foreground disabled:opacity-50">Verify & continue</button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
