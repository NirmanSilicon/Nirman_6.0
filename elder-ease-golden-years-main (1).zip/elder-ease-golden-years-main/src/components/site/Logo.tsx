import { Link } from "@tanstack/react-router";

export function LogoMark({ className = "h-11 w-11" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path d="M4 38 L18 16 L26 28 L32 20 L44 38 Z" fill="var(--teal)" opacity="0.35" />
      <rect x="20" y="10" width="14" height="24" rx="3" fill="none" stroke="var(--teal)" strokeWidth="3" />
      <path d="M12 40 C16 32 22 34 27 34 L34 34" fill="none" stroke="var(--navy)" strokeWidth="3" strokeLinecap="round" />
      <circle cx="27" cy="29" r="1.8" fill="var(--teal)" />
    </svg>
  );
}

export function Logo({ label }: { label?: string }) {
  return (
    <Link to="/" className="flex items-center gap-3 rounded-sm" aria-label="ElderEase home">
      <LogoMark />
      <span className="flex flex-col leading-tight">
        <span className="font-display text-2xl font-bold tracking-wide text-navy">ElderEase</span>
        {label && <span className="hidden text-[0.65rem] font-semibold tracking-mega text-muted-foreground sm:block">{label}</span>}
      </span>
    </Link>
  );
}
