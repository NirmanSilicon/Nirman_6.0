import { Link } from "@tanstack/react-router";
import { useApp } from "@/lib/app-context";
import { Logo } from "./Logo";
import { LanguageSelect, NAV } from "./Navbar";

export function Footer() {
  const { t } = useApp();
  return (
    <footer className="border-t border-border bg-sky-soft px-5 py-12 sm:px-10">
      <div className="grid gap-10 md:grid-cols-3">
        <div>
          <Logo label={t("platform")} />
          <p className="mt-4 text-lg text-muted-foreground">{t("tagline")}</p>
          <div className="mt-4"><LanguageSelect id="lang-footer" /></div>
        </div>
        <nav aria-label="Footer">
          <h2 className="text-lg font-bold tracking-wider text-navy">QUICK LINKS</h2>
          <ul className="mt-3 grid grid-cols-2 gap-1">
            {[...NAV, { to: "/impact", key: "impact" as const }, { to: "/join", key: "join" as const }].map((n) => (
              <li key={n.to}><Link to={n.to} className="inline-block py-1.5 text-lg text-navy hover:text-accent">{t(n.key)}</Link></li>
            ))}
          </ul>
        </nav>
        <div className="text-lg">
          <p className="font-bold text-navy">Presented by SheBuilds</p>
          <p className="text-muted-foreground">Nirman Hacknation</p>
          <p className="mt-4 text-muted-foreground">Cyber fraud helpline: <a className="font-bold text-navy underline" href="tel:1930">1930</a></p>
        </div>
      </div>
      <p className="mt-10 border-t border-border pt-6 text-center font-display text-base font-semibold tracking-wider text-navy">
        Digital empowerment. Shared learning. Greater independence.
      </p>
    </footer>
  );
}
