import { CheckCircle2, Clock } from "lucide-react";
import type { LearningModule } from "@/data/modules";
import { Icon } from "./Icon";

export function ModuleCard({ m, done, recommended, onOpen }: { m: LearningModule; done: boolean; recommended?: boolean; onOpen: () => void }) {
  return (
    <article className="relative flex flex-col rounded-md border-2 border-border bg-card p-6 transition-colors hover:border-teal">
      {recommended && <span className="absolute -top-3 left-5 rounded-sm bg-teal px-3 py-0.5 text-sm font-bold text-accent-foreground">Recommended for you</span>}
      <div className="flex items-center gap-4">
        <span className="grid h-16 w-16 shrink-0 place-items-center rounded-md bg-secondary text-accent"><Icon name={m.icon} className="h-9 w-9" /></span>
        <div className="min-w-0">
          <h3 className="text-xl font-bold text-navy">{m.title}</h3>
          <p className="flex items-center gap-1 text-base text-muted-foreground"><Clock className="h-4 w-4" aria-hidden /> {m.minutes} min · {m.level}</p>
        </div>
      </div>
      <p className="mt-4 flex-1 text-lg text-muted-foreground">{m.summary}</p>
      <div className="mt-5 flex items-center justify-between gap-3">
        <button onClick={onOpen} className="min-h-14 rounded-sm bg-primary px-6 font-semibold text-primary-foreground hover:opacity-90">
          {done ? "Review lesson" : "Start lesson"}
        </button>
        {done && <span className="flex items-center gap-1 font-semibold text-success"><CheckCircle2 className="h-6 w-6" aria-hidden /> Done</span>}
      </div>
    </article>
  );
}
