import { Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Home } from "lucide-react";
import type { ReactNode } from "react";
import { useApp } from "@/lib/app-context";
import { ListenButton } from "./ListenButton";

export function PageShell({ kicker, title, intro, children }: { kicker: string; title: string; intro: string; children: ReactNode }) {
  const { t } = useApp();
  const router = useRouter();
  return (
    <div className="animate-page-in">
      <div className="border-b border-border bg-sky-soft px-5 py-10 sm:px-10">
        <div className="mb-6 flex flex-wrap gap-3">
          <button onClick={() => router.history.back()} className="inline-flex min-h-14 items-center gap-2 rounded-sm border-2 border-navy bg-card px-5 font-semibold text-navy hover:bg-secondary">
            <ArrowLeft className="h-6 w-6" aria-hidden /> {t("back")}
          </button>
          <Link to="/" className="inline-flex min-h-14 items-center gap-2 rounded-sm border-2 border-navy bg-card px-5 font-semibold text-navy hover:bg-secondary">
            <Home className="h-6 w-6" aria-hidden /> {t("home")}
          </Link>
        </div>
        <p className="text-sm font-semibold tracking-mega text-accent">{kicker}</p>
        <h1 className="mt-2 text-4xl font-bold uppercase tracking-wider text-navy sm:text-5xl">{title}</h1>
        <p className="mt-4 max-w-3xl text-xl text-muted-foreground">{intro}</p>
        <ListenButton text={`${title}. ${intro}`} className="mt-5" />
      </div>
      <div className="px-5 py-12 sm:px-10">{children}</div>
    </div>
  );
}

export function SectionTitle({ kicker, title, center }: { kicker?: string; title: string; center?: boolean }) {
  return (
    <div className={center ? "text-center" : ""}>
      {kicker && <p className="text-sm font-semibold tracking-mega text-accent">{kicker}</p>}
      <h2 className="mt-2 text-3xl font-bold uppercase tracking-wider text-navy sm:text-4xl">{title}</h2>
    </div>
  );
}
