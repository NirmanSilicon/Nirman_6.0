import { Bar, BarChart, CartesianGrid, PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function WeeklyChart({ data }: { data: { day: string; minutes: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="day" tick={{ fontSize: 16, fill: "var(--navy)" }} />
        <YAxis tick={{ fontSize: 14, fill: "var(--navy)" }} />
        <Tooltip />
        <Bar dataKey="minutes" fill="var(--teal)" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function SkillsChart({ data }: { data: { skill: string; value: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <RadarChart data={data}>
        <PolarGrid stroke="var(--border)" />
        <PolarAngleAxis dataKey="skill" tick={{ fontSize: 14, fill: "var(--navy)" }} />
        <Radar dataKey="value" stroke="var(--teal)" fill="var(--teal)" fillOpacity={0.4} />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export function ProgressRing({ percent }: { percent: number }) {
  const r = 70, c = 2 * Math.PI * r;
  return (
    <svg viewBox="0 0 180 180" className="h-48 w-48" role="img" aria-label={`${percent}% complete`}>
      <circle cx="90" cy="90" r={r} fill="none" stroke="var(--secondary)" strokeWidth="18" />
      <circle cx="90" cy="90" r={r} fill="none" stroke="var(--teal)" strokeWidth="18" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - percent / 100)} transform="rotate(-90 90 90)" />
      <text x="90" y="100" textAnchor="middle" className="font-display" fontSize="34" fontWeight="700" fill="var(--navy)">{percent}%</text>
    </svg>
  );
}
