import { Contrast, Volume2, Accessibility, X } from "lucide-react";
import { useState } from "react";
import { useApp } from "@/lib/app-context";
import { speak } from "@/lib/speech";

export function AccessibilityToolbar() {
  const { t, scale, setScale, contrast, setContrast, speechLang } = useApp();
  const [open, setOpen] = useState(true);
  const btn = "grid min-h-14 min-w-14 place-items-center rounded-sm border-2 border-navy bg-card px-2 font-display font-bold text-navy hover:bg-secondary aria-pressed:bg-primary aria-pressed:text-primary-foreground";
  if (!open)
    return (
      <button onClick={() => setOpen(true)} aria-label="Open accessibility tools" className="fixed bottom-5 left-5 z-40 grid h-16 w-16 place-items-center rounded-full bg-teal text-accent-foreground shadow-lg">
        <Accessibility className="h-8 w-8" aria-hidden />
      </button>
    );
  return (
    <div role="toolbar" aria-label="Accessibility tools" className="fixed bottom-5 left-5 z-40 flex max-w-[calc(100vw-8rem)] flex-wrap items-center gap-2 rounded-md border border-border bg-card p-2 shadow-xl">
      <span className="sr-only">{t("textSize")}</span>
      <button className={btn} onClick={() => setScale(Math.max(0.9, scale - 0.1))} aria-label="Smaller text">A-</button>
      <button className={btn} onClick={() => setScale(1)} aria-label="Normal text size">A</button>
      <button className={btn} onClick={() => setScale(Math.min(1.5, scale + 0.1))} aria-label="Larger text">A+</button>
      <button className={btn} aria-pressed={contrast} onClick={() => setContrast(!contrast)} aria-label={t("contrast")}><Contrast className="h-6 w-6" aria-hidden /></button>
      <button
        className={`${btn} gap-1 px-3 sm:flex sm:items-center`}
        onClick={() => speak(document.querySelector("main")?.innerText.slice(0, 4000) ?? "", speechLang)}
      >
        <Volume2 className="h-6 w-6" aria-hidden /><span className="hidden text-sm sm:inline">{t("readPage")}</span>
      </button>
      <button onClick={() => setOpen(false)} aria-label="Hide accessibility tools" className="grid h-12 w-12 place-items-center text-muted-foreground"><X className="h-5 w-5" aria-hidden /></button>
    </div>
  );
}
