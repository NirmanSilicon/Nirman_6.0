import { useState } from "react";
import { MessageCircle, Wallet, Stethoscope, PhoneIncoming, CheckCircle2, RotateCcw, Lightbulb } from "lucide-react";

export type Scenario = "whatsapp" | "bill" | "doctor" | "fakecall";

const HINTS: Record<Scenario, string[]> = {
  whatsapp: ["Tap the green WhatsApp icon.", "Tap 'Beta Rahul' to open the chat.", "Type a message, then tap Send.", "Well done! Your message was sent."],
  bill: ["Tap the Pay app (wallet icon).", "Tap 'Electricity Bill'.", "Check the amount is ₹850, then enter the PIN 1234 (pretend).", "Payment done — with pretend money!"],
  doctor: ["Tap the Health app (stethoscope icon).", "Fill in your name and pick a time.", "Your appointment is booked!"],
  fakecall: ["Someone is calling. Listen to what they say.", "Good choice! That was a scam call."],
};

const btn = "min-h-14 w-full rounded-md px-3 text-base font-semibold";

export function PhoneSimulator({ scenario }: { scenario: Scenario }) {
  const [step, setStep] = useState(0);
  const [wrong, setWrong] = useState(false);
  const [text, setText] = useState("");
  const [pin, setPin] = useState("");
  const [name, setName] = useState("");
  const [slot, setSlot] = useState("");
  const hints = HINTS[scenario];
  const done = step === hints.length - 1;

  const reset = () => { setStep(0); setWrong(false); setText(""); setPin(""); setName(""); setSlot(""); };
  const go = (ok: boolean) => { if (ok) { setWrong(false); setStep((s) => s + 1); } else setWrong(true); };

  const apps = [
    { id: "whatsapp", label: "WhatsApp", I: MessageCircle },
    { id: "bill", label: "Pay", I: Wallet },
    { id: "doctor", label: "Health", I: Stethoscope },
  ];

  let screen;
  if (done) {
    screen = (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
        <CheckCircle2 className="h-20 w-20 text-success" aria-hidden />
        <p className="text-xl font-bold">{hints[step]}</p>
        <button onClick={reset} className={`${btn} flex items-center justify-center gap-2 bg-primary text-primary-foreground`}><RotateCcw className="h-5 w-5" aria-hidden /> Practise again</button>
      </div>
    );
  } else if (step === 0 && scenario !== "fakecall") {
    screen = (
      <div className="grid grid-cols-3 gap-3 pt-6">
        {apps.map(({ id, label, I }) => (
          <button key={id} onClick={() => go(id === scenario)} className="flex flex-col items-center gap-1 rounded-md p-2 hover:bg-secondary">
            <span className="grid h-16 w-16 place-items-center rounded-2xl bg-teal text-accent-foreground"><I className="h-8 w-8" aria-hidden /></span>
            <span className="text-sm font-semibold">{label}</span>
          </button>
        ))}
      </div>
    );
  } else if (scenario === "whatsapp" && step === 1) {
    screen = <div className="flex flex-col gap-2 pt-2">{["Beta Rahul", "Sunita (Neighbour)", "Family Group"].map((c) => <button key={c} onClick={() => go(c === "Beta Rahul")} className={`${btn} border border-border bg-card text-left`}>{c}</button>)}</div>;
  } else if (scenario === "whatsapp" && step === 2) {
    screen = (
      <div className="flex h-full flex-col justify-end gap-2">
        <p className="self-start rounded-md bg-card px-3 py-2">Hi Maa, how are you?</p>
        <label htmlFor="sim-msg" className="sr-only">Message</label>
        <input id="sim-msg" value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message" className="min-h-12 rounded-md border-2 border-input bg-card px-3" />
        <button onClick={() => go(text.trim().length > 0)} className={`${btn} bg-success text-accent-foreground`}>Send</button>
      </div>
    );
  } else if (scenario === "bill" && step === 1) {
    screen = <div className="flex flex-col gap-2 pt-2">{["Mobile Recharge", "Electricity Bill", "Send to friend"].map((c) => <button key={c} onClick={() => go(c === "Electricity Bill")} className={`${btn} border border-border bg-card text-left`}>{c}</button>)}</div>;
  } else if (scenario === "bill" && step === 2) {
    screen = (
      <div className="flex flex-col gap-3 pt-2">
        <p className="rounded-md bg-card p-3">TPCODL Electricity<br /><b className="text-2xl">₹850</b></p>
        <label htmlFor="sim-pin" className="font-semibold">Enter pretend UPI PIN (1234)</label>
        <input id="sim-pin" type="password" inputMode="numeric" maxLength={4} value={pin} onChange={(e) => setPin(e.target.value)} className="min-h-12 rounded-md border-2 border-input bg-card px-3 text-center text-2xl tracking-[0.5em]" />
        <button onClick={() => go(pin === "1234")} className={`${btn} bg-primary text-primary-foreground`}>Pay ₹850</button>
      </div>
    );
  } else if (scenario === "doctor" && step === 1) {
    screen = (
      <div className="flex flex-col gap-2 pt-2">
        <label htmlFor="sim-name" className="font-semibold">Your name</label>
        <input id="sim-name" value={name} onChange={(e) => setName(e.target.value)} className="min-h-12 rounded-md border-2 border-input bg-card px-3" />
        <p className="font-semibold">Choose a time</p>
        <div className="grid grid-cols-2 gap-2">{["10:00 AM", "11:30 AM", "4:00 PM", "5:30 PM"].map((s) => <button key={s} aria-pressed={slot === s} onClick={() => setSlot(s)} className={`min-h-12 rounded-md border-2 ${slot === s ? "border-teal bg-secondary" : "border-input bg-card"}`}>{s}</button>)}</div>
        <button onClick={() => go(name.trim() !== "" && slot !== "")} className={`${btn} bg-primary text-primary-foreground`}>Book appointment</button>
      </div>
    );
  } else {
    screen = (
      <div className="flex h-full flex-col items-center justify-between gap-3 pt-4 text-center">
        <PhoneIncoming className="h-14 w-14 animate-pulse text-accent" aria-hidden />
        <p className="text-lg font-bold">+91 70XXX 11223<br /><span className="font-normal">"Sir, I'm from your bank. Your card is blocked. Tell me the OTP to unblock it."</span></p>
        <div className="grid w-full grid-cols-1 gap-2">
          <button onClick={() => go(false)} className={`${btn} bg-success text-accent-foreground`}>Share the OTP</button>
          <button onClick={() => go(true)} className={`${btn} bg-destructive text-destructive-foreground`}>Hang up & call bank myself</button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-5 lg:flex-row lg:items-start lg:justify-center">
      <div className="relative h-[600px] w-[300px] shrink-0 rounded-[2.75rem] border-[12px] border-primary bg-primary shadow-2xl" aria-label="Practice phone">
        <div className="absolute left-1/2 top-1 h-5 w-24 -translate-x-1/2 rounded-full bg-primary" />
        <div className="flex h-full flex-col overflow-y-auto rounded-[2rem] bg-sky-soft p-4 text-foreground">
          <div className="mb-2 flex justify-between text-sm font-semibold"><span>9:41</span><span>PRACTICE</span></div>
          {screen}
        </div>
      </div>
      <div className="flex w-full max-w-sm flex-col gap-3" aria-live="polite">
        <div className="flex gap-3 rounded-md border-2 border-teal bg-card p-4">
          <Lightbulb className="h-7 w-7 shrink-0 text-accent" aria-hidden />
          <p className="text-xl">{hints[step]}</p>
        </div>
        {wrong && <p className="rounded-md bg-secondary p-4 text-xl font-semibold text-navy">Not quite — try again, no risk! 😊</p>}
        <p className="text-base text-muted-foreground">Step {Math.min(step + 1, hints.length)} of {hints.length}. Nothing here is real — no money moves.</p>
      </div>
    </div>
  );
}
