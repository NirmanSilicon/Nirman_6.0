import { useState } from "react";
import { Volume2, Square } from "lucide-react";
import { useApp } from "@/lib/app-context";
import { speak, stopSpeaking } from "@/lib/speech";
import { cn } from "@/lib/utils";

export function ListenButton({ text, className, label }: { text: string; className?: string; label?: string }) {
  const { t, speechLang } = useApp();
  const [on, setOn] = useState(false);
  return (
    <button
      type="button"
      onClick={() => {
        if (on) { stopSpeaking(); setOn(false); return; }
        setOn(true);
        speak(text, speechLang, () => setOn(false));
      }}
      aria-label={`${on ? t("stop") : t("listen")}: ${label ?? text.slice(0, 60)}`}
      className={cn(
        "inline-flex min-h-12 items-center gap-2 rounded-sm border-2 border-teal px-4 text-base font-semibold text-accent transition-colors hover:bg-teal hover:text-accent-foreground",
        className,
      )}
    >
      {on ? <Square className="h-5 w-5" aria-hidden /> : <Volume2 className="h-5 w-5" aria-hidden />}
      {on ? t("stop") : t("listen")}
    </button>
  );
}
