import { Icon } from "./Icon";
import { ListenButton } from "./ListenButton";

export function FeatureCard({ icon, title, text, index }: { icon: string; title: string; text: string; index?: number }) {
  return (
    <article className="flex flex-col rounded-md border border-border bg-card p-7 shadow-sm transition-shadow hover:shadow-lg">
      <div className="flex items-center justify-between">
        <span className="grid h-16 w-16 place-items-center rounded-full bg-secondary text-accent">
          <Icon name={icon} className="h-9 w-9" />
        </span>
        {index !== undefined && <span className="font-display text-4xl font-bold text-sky">0{index}</span>}
      </div>
      <h3 className="mt-5 text-xl font-bold text-navy">{title}</h3>
      <p className="mt-2 flex-1 text-lg text-muted-foreground">{text}</p>
      <ListenButton text={`${title}. ${text}`} label={title} className="mt-5 self-start" />
    </article>
  );
}
