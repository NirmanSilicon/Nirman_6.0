import { Languages, CalendarClock } from "lucide-react";

type Mentor = { id: string; name: string; role: string; languages: string[]; availability: string; photo: string };

export function MentorCard({ m, onBook }: { m: Mentor; onBook: (name: string) => void }) {
  return (
    <article className="flex flex-col rounded-md border border-border bg-card p-5 text-center shadow-sm">
      <img src={m.photo} alt={`Photo of ${m.name}`} width={112} height={112} loading="lazy" className="mx-auto h-28 w-28 rounded-full object-cover" />
      <h3 className="mt-3 text-xl font-bold text-navy">{m.name}</h3>
      <p className="text-base text-muted-foreground">{m.role}</p>
      <p className="mt-3 flex items-center justify-center gap-2 text-base"><Languages className="h-5 w-5 text-accent" aria-hidden /> {m.languages.join(", ")}</p>
      <p className="flex items-center justify-center gap-2 text-base"><CalendarClock className="h-5 w-5 text-accent" aria-hidden /> {m.availability}</p>
      <button onClick={() => onBook(m.name)} className="mt-4 min-h-14 rounded-sm bg-primary font-semibold text-primary-foreground hover:opacity-90">Book a session</button>
    </article>
  );
}
